const DealerDashboard = () => {
    return <div>DealerDashboard</div>
}

export default DealerDashboard
