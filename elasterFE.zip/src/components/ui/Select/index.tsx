import Select from './Select'

export type { SelectProps } from './Select'
export { Select }

export default Select
