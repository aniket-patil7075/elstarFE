import Pagination from './Pagination'

export type { PaginationProps } from './Pagination'
export { Pagination }

export default Pagination
