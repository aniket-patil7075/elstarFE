import Switcher from './Switcher'

export type { SwitcherProps } from './Switcher'
export { Switcher }

export default Switcher
