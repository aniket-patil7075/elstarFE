import Card from './Card'

export type { CardProps } from './Card'
export { Card }

export default Card
