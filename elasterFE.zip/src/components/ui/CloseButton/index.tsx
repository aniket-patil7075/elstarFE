import CloseButton from './CloseButton'

export type { CloseButtonProps } from './CloseButton'
export default CloseButton
