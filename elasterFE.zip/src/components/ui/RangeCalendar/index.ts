import RangeCalendar from '../DatePicker/RangeCalendar'

export type { RangeCalendarProps } from '../DatePicker/RangeCalendar'
export { RangeCalendar }
export default RangeCalendar
