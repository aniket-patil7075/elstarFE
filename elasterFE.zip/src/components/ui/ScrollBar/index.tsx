import ScrollBar from './ScrollBar'

export type { ScrollbarProps, ScrollbarRef } from './ScrollBar'
export { ScrollBar }

export default ScrollBar
