import i18n from './locales'

export { dateLocales } from './locales'
export default i18n
