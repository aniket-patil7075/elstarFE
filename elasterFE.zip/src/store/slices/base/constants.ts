export const SLICE_BASE_NAME = 'base'
