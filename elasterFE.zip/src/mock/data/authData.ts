export const signInUserData = [
    {
        id: '21',
        avatar: '/img/avatars/thumb-1.jpg',
        username: 'Carolyn Perkins',
        email: 'carolyn.p@elstar.com',
        authority: ['admin', 'user'],
        password: '12345Qwe1',
        accountUserName: 'admin',
    },
]
